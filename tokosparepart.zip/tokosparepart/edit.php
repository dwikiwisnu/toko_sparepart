<?php
//include('dbconnected.php');
include('dbconnect.php');

$kode = $_GET['kode_sparepart'];
$nama = $_GET['nama_sparepart'];
$type = $_GET['type_motor'];
$merk = $_GET['merk_motor'];
$harga = $_GET['harga_sparepart'];

//query update
$query = "UPDATE sparepart SET nama_sparepart='$nama' , merk_motor='$merk' , type_motor='$type' , harga_sparepart='$harga' WHERE kode_sparepart='$kode' ";

if (mysqli_query($conn, $query)) {
 # credirect ke page index
 header("location:index.php");
 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($conn);
}

mysqli_close($conn);
?>