<!DOCTYPE html>
<html lang="en">
<head>
 <title>Web Toko Sparepart Sepeda Motor</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
 <script src="js/jquery.js"></script>
 <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<?php 
$kode = $_GET['id']; 
//koneksi database
include('dbconnect.php');
//query
$query = "SELECT * FROM sparepart WHERE kode_sparepart='$kode'";
$result = mysqli_query($conn, $query);
?>

<div class="container bg-info" style="padding-top: 20px; padding-bottom: 20px;">
 <h3>Update Data Sparepart</h3>
 <form role="form" action="edit.php" method="get">
 <?php
 while ($row = mysqli_fetch_assoc($result)) {
 ?>

 <input type="hidden" name="kode_sparepart" value="<?php echo $row['kode_sparepart']; ?>">

 <div class="form-group">
  <label>Kode Sparepart</label>
  <input type="text" name="kode_sparepart" class="form-control" value="<?php echo $row['kode_sparepart']; ?>">   
 </div>

 <div class="form-group">
  <label>Nama Sparepart</label>
  <input type="text" name="nama_sparepart" class="form-control" value="<?php echo $row['nama_sparepart']; ?>">   
 </div>

 <div class="form-group">
  <label>Type Motor</label>
  <input type="text" name="type_motor" class="form-control" value="<?php echo $row['type_motor']; ?>">   
 </div>

 <div class="form-group">
  <label>Merk Motor</label>
  <input type="text" name="merk_motor" class="form-control" value="<?php echo $row['merk_motor']; ?>">   
 </div>

 <div class="form-group">
  <label>Harga Sparepart</label>
  <input type="text" name="harga_sparepart" class="form-control" value="<?php echo $row['harga_sparepart']; ?>">   
 </div>
 <button type="submit" class="btn btn-success btn-block">Update Sparepart</button>

 <?php 
 }
 mysqli_close($conn);
 ?>    
 </form>
</div>
</body>
</html>