<?php
//add dbconnect

include('dbconnect.php');

$kode = $_POST['kode_sparepart'];
$nama = $_POST['nama_sparepart'];
$type = $_POST['type_motor'];
$merk = $_POST['merk_motor'];
$harga = $_POST['harga_sparepart'];

//query

$query =  "INSERT INTO sparepart(kode_sparepart , nama_sparepart , type_motor, merk_motor , harga_sparepart) VALUES('$kode' , '$nama' , '$type', '$merk' , '$harga')";

if (mysqli_query($conn , $query)) {
 # code redicet setelah insert ke index
 header("location:index.php");
}
else{
 echo "ERROR, tidak berhasil". mysqli_error($conn);
}

mysqli_close($conn);
?>